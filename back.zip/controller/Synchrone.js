const crypto = require('crypto');
const express = require('express');
const bodyParser = require('body-parser');


const CryptoFunction = {
    encrypt: async(req, res)=>{
        
    },

    decrypt: async(req,res) =>{
        
    }
}
